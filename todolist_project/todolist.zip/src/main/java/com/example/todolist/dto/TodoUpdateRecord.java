package com.example.todolist.dto;

public record TodoUpdateRecord(String content) {
}
