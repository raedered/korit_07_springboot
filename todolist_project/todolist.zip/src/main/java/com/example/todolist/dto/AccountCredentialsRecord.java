package com.example.todolist.dto;

public record AccountCredentialsRecord(String username, String password) {
}
