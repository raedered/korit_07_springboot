package com.example.todolist.dto;

public record TodoRequestRecord(String content) {}
